<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<style>




	.header{
        text-align: center;
        color: red;
		}
    * {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial Helvetica sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: black;
}

.topnav a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #00BFFF;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
 


h2 {
    color: white;
    text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
}
h1 {
    color: white;
    text-shadow: 2px 2px 4px #000000;
}
h1 {
    text-shadow: 0 0 3px #FF0000;
}
.container {
    background-image: url("hotel25.jpg");
}


.context-dark, .bg-gray-dark, .bg-primary {
    color: rgba(255, 255, 255, 0.8);
}

.footer-classic a, .footer-classic a:focus, .footer-classic a:active {
    color: #ffffff;
}
.nav-list li {
    padding-top: 5px;
    padding-bottom: 5px;
}

.nav-list li a:hover:before {
    margin-left: 0;
    opacity: 1;
    visibility: visible;
}

ul, ol {
    list-style: none;
    padding: 0;
    margin: 0;
}


.nav-list li a:before {
    content: "\f14f";
    font: 400 21px/1 "Material Design Icons";
    color: #4d6de6;
    display: inline-block;
    vertical-align: baseline;
    margin-left: -28px;
    margin-right: 7px;
    opacity: 0;
    visibility: hidden;
    transition: .22s ease;
}



</style>
</head>
<body>



<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}

</script>
  
  <br><br><br><br><br>

 <div class="topnav">
  <div class="sticky">
  <a class="active" href="index.php">Home</a>
  <a href="gallery.php">Gallery</a>
  <a href="offer.php">Latest Offer</a>
  <a href="events.php">Events</a>
  <a href="chart.php">Statics</a>
  <?php if (!empty($_SESSION["NAME"])) { ?>
  <a href="#">Hii, <?php echo $_SESSION["NAME"];?></a>
  <a href="logout.php">logout</a>
  <?php }
  else { ?>
  <a href="loginuser.php">Login</a>
  <a href="contact.php">Register</a>
  <?php } ?>
  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
  </div>
</div><br><br><br><br><br><br>



<div class="row">
  <center> <font style="font-size: 35px;color:red;font-size: 40px"><b><i> HOTTEST    DEALS !</i></b> </font></center><hr style="margin-left: 400px;margin-right: 400px color:black ">
  <font style="text-align: center;color: red;size: 20px;margin-right: 500px;margin-left: 500px"> Dream Rooms Tend To Lead People To Do Things They Wouldn't Necessarily Do At Home</font>
</div><br><br>
<div class="row">
  <img src="hotel1.jpg" style="width: 100%; height: 700px">
</div>
<br><br><br><br>
<div class="row">
  <center><font style="font-size: 20px;color: blue"><i><b>TODAY'S  DEALS</b></i><br>
    <p style="color: blue">__________________</p></font></center>
</div>
<div class="row well">
    <div class="col-md-3 col-md-offset-1">
    <img src="hotel42.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL ROYAL ORCHID</font><br>
    <font style="font-size: 13px">45 South Street Area,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">80% OFF</font><br><br>
    <font style="color: ">Last Room Available!  HURRY UP</font><br>
    <del style="color: red;size: 20px">RS. 10314</del><br>
    <font style="color: red;size: 20px">RS. 3823</font><br>
    <button style="color: black">BOOK IT NOW</button>

  </div>

  <div class="col-md-3 col-md-offset-1">
    <img src="hotel40.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL AAPNO RAJASTHAN</font><br>
    <font style="font-size: 13px">Near 21 Bajaj Nagar ,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">FLAT 50% OFF</font><br><br>
    <font style="color: ">Last Room Available!  HURRY UP</font><br>
    <del style="color: red;size: 20px">RS. 10314</del><br>
    <font style="color: red;size: 20px">RS. 3823</font><br>
    <button style="color: black">BOOK IT NOW</button>
    
  </div>
  <div class="col-md-3 col-md-offset-1">
    <img src="hotel57.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL RAJMAHAL</font><br>
    <font style="font-size: 13px">34 Ambarpali Street,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">25% OFF</font><br><br>
    <font style="color: ">Offer Closed</font><br>
    <del style="color: red;size: 20px">RS. 12344</del><br>
    <font style="color: red;size: 20px">RS. 8763</font><br>
    <button style="color: black">BOOK IT NOW</button>
    
  </div>


</div>

	
<div class="row well">
    <div class="col-md-3 col-md-offset-1">
    <img src="hote46.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL MAHARAJA</font><br>
    <font style="font-size: 13px">Near Ajmer Road,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">60% OFF</font><br><br>
    <font style="color: ">Last Room Available!  HURRY UP</font><br>
    <del style="color: red;size: 20px">RS. 10214</del><br>
    <font style="color: red;size: 20px">RS. 5823</font><br>
    <button style="color: black">BOOK IT NOW</button>
  </div>

  <div class="col-md-3 col-md-offset-1">
    <img src="hote48.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL INDIANA</font><br>
    <font style="font-size: 13px">45 South Street Area,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">80% OFF</font><br><br>
    <font style="color: ">Last Room Available!  HURRY UP</font><br>
    <del style="color: red;size: 20px">RS. 10314</del><br>
    <font style="color: red;size: 20px">RS. 3823</font><br>
   <button style="color: black">BOOK IT NOW</button>
  </div>
  <div class="col-md-3 col-md-offset-1">
    <img src="hote47.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL AJMERA</font><br>
    <font style="font-size: 13px">Near World Trade Park Malviya Nagar,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">FLAT 50% OFF</font><br><br>
    <font style="color: ">Last Room Available!  HURRY UP</font><br>
    <del style="color: red;size: 20px">RS. 10004</del><br>
    <font style="color: red;size: 20px">RS. 5002</font><br>
    <button style="color: black">BOOK IT NOW</button>
  </div>


</div>


<div class="row well">
    <div class="col-md-3 col-md-offset-1">
    <img src="hotel56.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL VILLA</font><br>
    <font style="font-size: 13px">Main Street Jawahar Circle,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">60% OFF</font><br><br>
    <font style="color: ">Last Room Available!  HURRY UP</font><br>
    <del style="color: red;size: 20px">RS. 10314</del><br>
    <font style="color: red;size: 20px">RS. 4823</font><br>
    <button style="color: black">BOOK IT NOW</button>
  </div>

  <div class="col-md-3 col-md-offset-1">
    <img src="hotel58.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL ITC</font><br>
    <font style="font-size: 13px">Ghoot Ki Ghani Transport Nagar ,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">FLAT 25% OFF</font><br><br>
    <font style="color: ">Last Room Available!  HURRY UP</font><br>
    <del style="color: red;size: 20px">RS. 10214</del><br>
    <font style="color: red;size: 20px">RS. 7823</font><br>
    <button style="color: black">BOOK IT NOW</button>
  </div>
  <div class="col-md-3 col-md-offset-1">
    <img src="hotel55.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL ESCORT</font><br>
    <font style="font-size: 13px"> Ram Nagar Street Ajmer Road,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">35% OFF</font><br><br>
    <font style="color: ">Offer Closed</font><br>
    <del style="color: red;size: 20px">RS. 10544</del><br>
    <font style="color: red;size: 20px">RS. 6763</font><br>
    <button style="color: black">BOOK IT NOW</button>
  </div>


</div>

<div class="row well">
    <div class="col-md-3 col-md-offset-1">
    <img src="hotel51.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL RAMBAGH</font><br>
    <font style="font-size: 13px"> South Street Jhotwada,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">90% OFF</font><br><br>
    <font style="color: ">Last Room Available!  HURRY UP</font><br>
    <del style="color: red;size: 20px">RS. 10314</del><br>
    <font style="color: red;size: 20px">RS. 2823</font><br>
    <button style="color: black">BOOK IT NOW</button>
  </div>

  <div class="col-md-3 col-md-offset-1">
    <img src="hotel59.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL YUVRAJ</font><br>
    <font style="font-size: 13px">Near 21 Bajaj Nagar ,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">FLAT 50% OFF</font><br><br>
    <font style="color: ">Last Room Available!  HURRY UP</font><br>
    <del style="color: red;size: 20px">RS. 13144</del><br>
    <font style="color: red;size: 20px">RS. 7823</font><br>
    <button style="color: black">BOOK IT NOW</button>
  </div>
  <div class="col-md-3 col-md-offset-1">
    <img src="hotel555.jpg" style="height: 300px; width: 100%"><br><br>
    <font style="font-size: 25px;color: brown">HOTEL AMBARWALI</font><br>
    <font style="font-size: 13px">34 Ambarpali Street,Jaipur</font><br><br>
    <font style="font-size: 16px;color: blue">20% OFF</font><br><br>
    <font style="color: ">Offer Closed</font><br>
    <del style="color: red;size: 20px">RS. 15344</del><br>
    <font style="color: red;size: 20px">RS. 13763</font><br>
    <button style="color: black">BOOK IT NOW</button>
  </div>


</div>


<br><br>
 <footer class="section footer-classic context-dark bg-image" style="background: #2d3246;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
              <div class="pr-xl-4"><a class="brand" href="index.php"><img class="brand-logo-light" src="images/agency/logo-inverse-140x37.png" alt="" width="140" height="37" srcset="images/agency/logo-retina-inverse-280x74.png 2x"></a>
                <p style="color: red;size: 30px ">Our goal is to change the way people stay away from home</p>
                <!-- Rights-->
                <p class="rights"><span>©  </span><span class="copyright-year">2018</span><span> </span><span>Waves</span><span>. </span><span>All Rights Reserved.</span></p>
              </div>
            </div>
            <div class="col-md-4">
              <h5>Contacts</h5>
              <dl class="contact-list">
                <dt>Address:</dt>
                <dd>798 South Park Avenue, Jaipur, Raj</dd>
              </dl>
              <dl class="contact-list">
                <dt>email:</dt>
                <dd><a href="shivam098t@gmail.com">shivam098t@gmail.com</a></dd>
              </dl>
              <dl class="contact-list">
                <dt>phones:</dt>
                <dd><a href="tel:#">+91 7568543012</a> <span>or</span> <a href="tel:#">+91 9571195353</a>
                </dd>
              </dl>
            </div>
            <div class="col-md-4 col-xl-3">
              <h5>Links</h5>
              <ul class="nav-list">
                <li><a href="index.php">About</a></li>
                <li><a href="gallery.php">Visit Our Gallery</a></li>
                <li><a href="offer.php">Hot Deals</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="contact.php">Register</a></li>
              </ul>
            </div>
          </div>
        </div>
   
      </footer>

</body>
</html>
