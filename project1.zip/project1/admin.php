<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

			<?php 
			$servername="localhost";
			$username="root";
			$password="";
			$dbname="ehotels";
			$conn=mysqli_connect($servername,$username,$password,$dbname);
			$sql="Select * FROM registration";
			$result=mysqli_query($conn,$sql);
			echo "<table border='2'>";
			if(mysqli_num_rows($result)>0)
				{
					 while($row=mysqli_fetch_assoc($result))
					 	{
					 		?>
					 			<tr><td><?php echo $row["first_name"];?></td>
					 				<td><?php echo $row["last_name"]; ?></td>
					 				<td><?php echo $row["mobileno"]; ?></td>
					 				<td><?php echo $row["email"]; ?></td></tr>
					 		<?php }
					 		}
					 			echo "</table>"; ?>
</body>
</html>