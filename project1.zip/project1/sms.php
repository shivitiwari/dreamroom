<?php
$mobile="8278664750";
$message="good morning";
$json = json_decode(file_get_contents("https://smsapi.engineeringtgr.com/send/?Mobile=8502071173&Password=pstmerabhai&Message=".urlencode($message)."&To=".urlencode($mobile)."&Key=ravibm4FoD7dWGu6bvpCK5J") ,true);
if ($json["status"]==="success") {
    echo $json["msg"];
    //your code when send success
}else{
    echo $json["msg"];
    //your code when not send
}
?>