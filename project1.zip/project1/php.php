<?php 
$a=4;
echo "<b><br>Your details has been recorded<b><br><br><br>";
echo "<i><b>Thank you For Your Contacting Us<b><i><br><br>";
echo "",2+5,"<br><br>";
echo "",floor(3.20),"<br><br>";
echo sqrt(++$a);
echo "",dechex(16),"<br><br>";
echo "",pow(3, 4),"<br><br>";
echo "",rad2deg(atan(1)) ?>