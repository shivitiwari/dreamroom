<?php
$servername="localhost";
$username="root";
$password="";
$dbname="ehotels";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
$first_name=$_POST['s0'];
$last_name=$_POST['s1'];
$mobileno=$_POST['s2'];
$email=$_POST['s3'];
$password=$_POST['s4'];
$gender=$_POST['s5'];

$sql="INSERT INTO `registration`(`first_name`, `last_name`, `mobileno`, `email`, `password`, `gender`) VALUES ('$first_name','$last_name','$mobileno','$email','$password','$gender')";
if (mysqli_query($conn,$sql))
 {
echo"<script>window.location.assign('loginuser.php');</script>";
}
else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
?>
