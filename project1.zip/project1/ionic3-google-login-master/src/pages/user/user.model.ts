export class UserModel {
  picture: string;
  email: string;
  name: string;
}
