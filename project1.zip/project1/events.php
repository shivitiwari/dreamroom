<?php
session_start();
?>
<!DOCTYPE html>
<html>

<head>
<title>Dream Rooms</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

  
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


	
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>




<style>


  	

  	.header{
        text-align: center;
        color: red;
		}
    * {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial Helvetica sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: black;
}

.topnav a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #00BFFF;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
 .circleimage{
  text-align: center;
  border-image: solid;

 }
 .imagetop{
  margin-top:-260px;
  margin-left: 850px;

 }
  .top{
  margin-top:-280px;
  margin-right: 900px;
 }   
 .topnav.sticky {
    position: -webkit-sticky;
    position: sticky;
    top: 0;
    } 
    





.mySlides {display:none;}

.width{
	width: 500px
}


  .box{
      width: 100%;
      height: 500px;


  }
.box1{
  width: 100%;
      height: 500px;
      border: 2px solid;

}






 .context-dark, .bg-gray-dark, .bg-primary {
    color: rgba(255, 255, 255, 0.8);
}

.footer-classic a, .footer-classic a:focus, .footer-classic a:active {
    color: #ffffff;
}
.nav-list li {
    padding-top: 5px;
    padding-bottom: 5px;
}

.nav-list li a:hover:before {
    margin-left: 0;
    opacity: 1;
    visibility: visible;
}

ul, ol {
    list-style: none;
    padding: 0;
    margin: 0;
}


.nav-list li a:before {
    content: "\f14f";
    font: 400 21px/1 "Material Design Icons";
    color: #4d6de6;
    display: inline-block;
    vertical-align: baseline;
    margin-left: -28px;
    margin-right: 7px;
    opacity: 0;
    visibility: hidden;
    transition: .22s ease;
}






</style>
</head>

<body>
 <div class="topnav">
  <div class="sticky">
  <a class="active" href="index.php">Home</a>
  <a href="gallery.php">Gallery</a>
  <a href="offer.php">Latest Offer</a>
  <a href="events.php">Events</a>
  <a href="chart.php">Statics</a>
  <a href="admin.php">Admin_Page</a>
  <?php if (!empty($_SESSION["NAME"])) { ?>
  <a href="#">Hii, <?php echo $_SESSION["NAME"];?></a>
  <a href="logout.php">logout</a>
  <?php }
  else { ?>
  <a href="loginuser.php">Login</a>
  <a href="contact.php">Register</a>
  <?php } ?>
  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
  </div>
</div><br><br><br><br><br><br>




<h2 class="w3-center" style="text-align: center;">EVENTS AND MEETINGS</h2>
<hr>
<p style="text-align: center"><b><i>The Great Advantage Of Dream Rooms Is That It Is A Refuge From A Home Life<i></b></p>
<br><br>
<div class="w3-content w3-section" style="max-width:900px">
  <img class="mySlides" src="event1.jpg" style="height: 500px;width: 100%">
  <img class="mySlides" src="event2.jpg" style="width:100%">
  <img class="mySlides" src="event3.jpg" style="width:100%">
</div>


<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>

<hr>
<br><br><br><br><br><br><br><br><br>


<div class="container">

<img src="event5.jpg" class="image" style="width: 700px;height: 500px;margin-left: -150px">
<h1 style="margin-left: 800px;margin-top: -500px ;margin-right: 400px"><b>WEEDING FOOD</b></h1><hr>
<p style="margin-left: 800px;margin-top: -20px">Dream Rooms Are Serving You With Royal Food On Many Weeding Ceremony!
The central courtyard, visible from the lobby, restaurant and rooms, has a water body where performances by local folk dancers and musical jugalbandi is held during the evening. This magnificent space is also a wonderful setting for Indian wedding rituals like ring ceremony, Mehendi, Pheras and more.</p>


<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<img src="event6.jpg" style="width: 700px;height: 500px;margin-left: 700px">
<h1 style="margin-right: 1000px;margin-top: -500px ;margin-left: 300px"><b>Dance Events</b></h1><hr>
<p style="margin-right: 600px;margin-top: -20px;margin-left: 80px">Dream Rooms Are Being inclusive is the need of the hour. It brings creativity, drives originality of thought, helps us understand our customer better. It is important for an organization to be inclusive – as a brand we understand our clients better and as an employer your employees are happier and loyal as they bring their whole self to work.</p><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<img src="i.jpg" class="image" style="width: 700px;height: 500px;margin-left: -150px">
<h1 style="margin-left: 800px;margin-top: -500px ;margin-right: 500px"><b>VALENTINE'S MOMENTS</b></h1><hr>
<p style="margin-left: 850px;margin-top: -20px">Dream Rooms Are is a safe, gender agnostic place. Our message to the world is #PureLove and we welcome everyone without any discrimination on the basis of gender, sexual preferences, religion, physical abilities. We respect everyone’s choices and celebrate diversity! </p>


<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<img src="event8.jpg" style="width: 700px;height: 500px;margin-left: 700px">
<h1 style="margin-right: 800px;margin-top: -500px ;margin-left: 100px"><b>MOVIE CELEBRATION</b></h1><hr>
<p style="margin-right: 800px;margin-top: -20px;margin-left: 80px">Dream Rooms Are Representing With Such A Big Movie Party And Fashion Shows And You To Be A Part Of It!</p><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<img src="event9.jpg" class="image" style="width: 700px;height: 500px;margin-left: -150px">
<h1 style="margin-left: 800px;margin-top: -500px ;margin-right: 500px"><b>OFFICE SEMINAR'S</b></h1><hr>
<p style="margin-left: 800px;margin-top: -20px">We Offers You To Seminar Halls For Discussing Your Projects And Views!
Steeped in luxury and elegance, the 6,237 sq ft pillar less ballroom comes with an expansive pre-function area, opening on to the party lawns. The ballroom can be further partitioned into two separate halls. Customized banquet menus are crafted by our chefs to suit corporate events, product launches, conferences, seminars, private parties, weddings and more.</p>


<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<img src="event4.jpg" style="width: 700px;height: 500px;margin-left: 700px">
<h1 style="margin-right: 1000px;margin-top: -500px ;margin-left: 300px"><b>DISCO NIGHT</b></h1><hr>
<p style="margin-right: 600px;margin-top: -20px;margin-left: 80px">You Will Enjoy Our Big Madness On New Year And All Festivals!is the need of the hour. It brings creativity, drives originality of thought, helps us understand our customer better. It is important for an organization to be inclusive – as a brand we understand our clients better and as an employer your employees are happier and loyal as they bring their whole self to work.</p><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

</div>


<br><br><br><br><br><br><br><br>

  <footer class="section footer-classic context-dark bg-image" style="background: #2d3246;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
              <div class="pr-xl-4"><a class="brand" href="index.html"><img class="brand-logo-light" src="images/agency/logo-inverse-140x37.png" alt="" width="140" height="37" srcset="images/agency/logo-retina-inverse-280x74.png 2x"></a>
                <p style="color: red;size: 30px ">Our goal is to change the way people stay away from home</p>
                <!-- Rights-->
                <p class="rights"><span>©  </span><span class="copyright-year">2018</span><span> </span><span>Dream_Rooms</span><span>. </span><span>All Rights Reserved By dreamrooms.com</span></p>
              </div>
            </div>
            <div class="col-md-4">
              <h5>Contacts</h5>
              <dl class="contact-list">
                <dt>Address:</dt>
                <dd>798 South Park Avenue, Jaipur, Raj</dd>
              </dl>
              <dl class="contact-list">
                <dt>email:</dt>
                <dd><a href="shivam098t@gmail.com">shivam098t@gmail.com</a></dd>
              </dl>
              <dl class="contact-list">
                <dt>phones:</dt>
                <dd><a href="tel:#">+91 7568543012</a> <span>or</span> <a href="tel:#">+91 9571195353</a>
                </dd>
              </dl>
            </div>
            <div class="col-md-4 col-xl-3">
              <h5>Links</h5>
              <ul class="nav-list">
                <li><a href="index.php">About</a></li>
                <li><a href="gallery.php">Visit Our Gallery</a></li>
                <li><a href="offer.php">Hot Deals</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="contact.php">Register</a></li>
              </ul>
            </div>
          </div>
        </div>
   
      </footer>






</body>
</html>
