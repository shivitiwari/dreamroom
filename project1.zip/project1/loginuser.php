<?php 
if (!empty($_SESSION["NAME"])) {
  header('location:index.php');}
  else
  {
    //Include GP config file && User class
include_once 'gpConfig.php';
include_once 'User.php';

if(isset($_GET['code'])){
  $gClient->authenticate($_GET['code']);
  $_SESSION['token'] = $gClient->getAccessToken();
  header('Location: ' . filter_var($redirectURL, FILTER_SANITIZE_URL));
}

if (isset($_SESSION['token'])) {
  $gClient->setAccessToken($_SESSION['token']);
}

if ($gClient->getAccessToken()) {
  //Get user profile data from google
  $gpUserProfile = $google_oauthV2->userinfo->get();
  
  //Initialize User class
  $user = new User();
  
  //Insert or update user data to the database
    $gpUserData = array(
        'oauth_provider'=> 'google',
        'oauth_uid'     => $gpUserProfile['id'],
        'first_name'    => $gpUserProfile['given_name'],
        'last_name'     => $gpUserProfile['family_name'],
        'email'         => $gpUserProfile['email'],
        'gender'        => $gpUserProfile['gender'],
        'locale'        => $gpUserProfile['locale'],
        'picture'       => $gpUserProfile['picture'],
        'link'          => $gpUserProfile['link']
    );
    $userData = $user->checkUser($gpUserData);
  
  //Storing user data into session
  $_SESSION['userData'] = $userData;
  
  //Render facebook profile data
    if(!empty($userData)){
        $output = '<h1>Google+ Profile Details </h1>';
        $output .= '<img src="'.$userData['picture'].'" width="300" height="220">';
        $output .= '<br/>Google ID : ' . $userData['oauth_uid'];
        $output .= '<br/>Name : ' . $userData['first_name'].' '.$userData['last_name'];
        $output .= '<br/>Email : ' . $userData['email'];
        $output .= '<br/>Gender : ' . $userData['gender'];
        $output .= '<br/>Locale : ' . $userData['locale'];
        $output .= '<br/>Logged in with : Google';
        $output .= '<br/><a href="'.$userData['link'].'" target="_blank">Click to Visit Google+ Page</a>';
        $output .= '<br/>Logout from <a href="logout.php">Google</a>'; 
    }else{
        $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
    }
} else {
  $authUrl = $gClient->createAuthUrl();
  $output = '<a href="'.filter_var($authUrl, FILTER_SANITIZE_URL).'"><img src="images/glogin.png" alt=""/></a>';
}
 ?>
<!DOCTYPE html>
<html>
<head>

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 
  <script type="text/javascript">
    function ok(){
      var a=document.getElementById("1").value;
      var b=document.getElementById("2").value;
      if (a="" || b="") {
        window.location.assign("./contact.php");
      }
    }
  </script>

  <title> LOGIN FORM DESIGN</title>
  <link rel="stylesheet" type="text/css" href="NEW.css">
</head>
<body>
  <div class="row well">
      <div class="col-md-offset-4 col-md-4 well" style="border: 2px solid black;">
        <center><p style="font-size: 20px;font-weight: bolder;">Login</p></center>
              <form method="post">
                <label>E-mail:</label>
                <input type="email" name="email" placeholder="Enter Your Email*" class="form-control" id="1" ><br>
                <label>Password:</label>
                 <input type="password" name="password" placeholder="Enter Your Password*" class="form-control" id="2" ><br><br>
                 <input type="submit" name="submit" value="Login" class="form-control btn btn-success"><br><br>
                 <input type="reset" class="form-control btn btn-danger"><br><br><br></form>
                 <center><label><a href="forgot.php" ><button class="btn btn-success">Forgot Password</button></a></label></center><br>
                 <center><label><a href="contact.php" ><button class="btn btn-success">SignUp</button></a></label></center>
              <?php echo $output; ?>
      </div>
    </center>
  </div>
</div>
</div>

    <?php 
                           
                        if (isset($_POST['submit'])) {
                                
                                 $a=$_POST['email'];
                                $b=$_POST['password'];
                                $servername="localhost";
                                $username="root";
                                $password="";
                                $dbname="ehotels";

                                $conn=mysqli_connect($servername,$username,$password,$dbname);
                          $sql="select * FROM registration WHERE email='$a' && password='$b'";
                            $result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result)){
                                    session_start();
                                    $row=mysqli_fetch_assoc($result);
                    $_SESSION["NAME"]=$row['first_name'];$_SESSION["EMAIL"]=$row['email'];
                                    header('location: index.php');
                           }
                                else
                                {
                            ?>
                            <script>
                                alert("wrong inputs");
                                </script>
                            <?php
                                }
                        }

                      }
                       ?>

</body>
</html>
