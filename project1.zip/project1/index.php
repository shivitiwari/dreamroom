<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<link rel="icon" type="x-icon" href="logo.jpg">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



   <script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>

	<title></title>
	<link rel="stylesheet" type="text/css" href="home.css">
	<style type="text/css">

   



   .context-dark, .bg-gray-dark, .bg-primary {
    color: rgba(255, 255, 255, 0.8);
}

.footer-classic a, .footer-classic a:focus, .footer-classic a:active {
    color: #ffffff;
}
.nav-list li {
    padding-top: 5px;
    padding-bottom: 5px;
}

.nav-list li a:hover:before {
    margin-left: 0;
    opacity: 1;
    visibility: visible;
}

ul, ol {
    list-style: none;
    padding: 0;
    margin: 0;
}


.nav-list li a:before {
    content: "\f14f";
    font: 400 21px/1 "Material Design Icons";
    color: #4d6de6;
    display: inline-block;
    vertical-align: baseline;
    margin-left: -28px;
    margin-right: 7px;
    opacity: 0;
    visibility: hidden;
    transition: .22s ease;
}








		.header{
        text-align: center;
        color: red;
		}
    * {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial Helvetica sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: black;
}

.topnav a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #00BFFF;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
 .circleimage{
  text-align: center;
  border-image: solid;

 }
 .imagetop{
  margin-top:-260px;
  margin-left: 850px;

 }
  .top{
  margin-top:-280px;
  margin-right: 900px;
 }   
 .topnav.sticky {
    position: -webkit-sticky;
    position: sticky;
    top: 0;
    } 
    body{
  font-family: Arial;
  margin: 0;
}

* {
  box-sizing: border-box;
}

img {
  vertical-align: middle;
}

/* Position the image container (needed to position the left and right arrows) */
.container {
  position: relative;
}

/* Hide the images by default */
.mySlides {
  display: none;
}

/* Add a pointer when hovering over the thumbnail images */
.cursor {
  cursor: pointer;
}

/* Next & previous buttons */
.prev,
.next {
  cursor: pointer;
  position: absolute;
  top: 40%;
  width: auto;
  padding: 16px;
  margin-top: -50px;
  color: white;
  font-weight: bold;
  font-size: 20px;
  border-radius: 0 3px 3px 0;
  user-select: none;
  -webkit-user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover,
.next:hover {
  background-color: rgba(0, 0, 0, 0.8);
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* Container for image text */
.caption-container {
  text-align: center;
  background-color: #222;
  padding: 2px 16px;
  color: white;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Six columns side by side */
.column {
  float: left;
  width: 16.66%;
}

/* Add a transparency effect for thumnbail images */
.demo {
  opacity: 0.6;
}

.active,
.demo:hover {
  opacity: 1;
} 
	</style>

</head>
<body>
 <div class="topnav">
  <div class="sticky">
  <a class="active" href="index.php">Home</a>
  <a href="gallery.php">Gallery</a>
  <a href="offer.php">Latest Offer</a>
  <a href="events.php">Events</a>
  <a href="chart.php">Statics</a>
  <?php if (!empty($_SESSION["NAME"])) { ?>
  <a href="#">Hii, <?php echo $_SESSION["NAME"];?></a>
  <a href="logout.php">logout</a>
  <a href="admin.php">Admin_Page</a>
  <?php }
  else { ?>
  <a href="loginuser.php">Login</a>
  <a href="contact.php">Register</a>
  <?php } ?>
  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
  </div>
</div><br>   

     
    <div class="container-fluid">

    
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">

      <div class="item active">
        <img src="hote10.jpg" alt="Los Angeles" style="width:100%;">
        
      </div>

      <div class="item">
        <img src="alaska.jpg" alt="Chicago" style="width:100%;">
      </div>
    
      <div class="item">
        <img src="hote14.jpg" alt="New York" style="width:100%;">
              </div>
  </div>
  <div style="position: absolute;top:0;width: 100%;height: 100%;z-index:99;background-color:;opacity:1"><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <h1 style=""><div class="header">
  <h1 style=""><label>Welcome to Dream Rooms</label></h1>
  <p style="color: blue;font-weight: bolder; size: 40px"><i>A House Is Made Up Of Bricks And Beams.
  Dream Homes Are Made Up Of Hopes And Dreams</i></p><hr style="margin-left: 400px; margin-right: 400px"><br><br><br><br>
 </div>
  </div>
</div>
</div>
<br><br><br><br>
<div style="margin-top: 0px">
   <h2 style="text-align: center;color: red">Why you Choose Us</h2><br><hr style="color: black; margin-right: 300px;margin-left: 300px">
   <p style="text-align: center;color: red"><i>Dreams Rooms Will Always For You When You Need Someone To Share Your Dreams!</i></p></div>
   <br><br><br><br><br>
 

 <div class="container">
 <div class="row well"> 

  <div class="col-md-3">
  <img src="hote25.jpg" class="img-circle" alt="Cinque Terre" width="304" height="236"> 
   <font style="font-size: 25px;color: brown">Standardized</font><br>
     <font style="font-size: 16px">Dream Rooms promises to provide the same amenities and the same awesome experience across all its rooms!</font><br><br>
   <p>
   </div>
 
 
   <div class="col-md-3 col-md-offset-1">
    <img src=" hotel42.jpg " class="img-circle" alt="Cinque Terre" width="304" height="236">
    <font style="font-size: 25px;color: brown">Affordable</font><br>
     <font style="font-size: 16px">We offers rooms at prices that no other player in the budget segment offers today!</font><br><br>
   </div>

   <div class="col-md-3 col-md-offset-1">
   <img src="hotel40.jpg" class="img-circle" alt="Cinque Terre" width="304" height="236">
   <font style="font-size: 25px;color: brown">Technology Driven</font><br>
     <font style="font-size: 16px">The most advanced hospitality tech takes shape here. We introduced pioneering technology to the hospitality industry to deliver better and more efficient operations, management, service and CRM. Our app allows a user to book a room in just 3 taps, or within 5 seconds!</font><br><br>
     
   </div>

</div>
</div>
   
   <br><br><br><br><br><br>

  


 <h2 style="text-align:center;color: blue">Our Offers</h2><hr>
 <p style="text-align: center;color: blue"><i>Dream Rooms Offers The Best Way To Find Your Homes</i></p>

<div class="container">
  <div class="mySlides">
    <div class="numbertext">1 / 6</div>
    <img src="hote00.jpg" style="width:100%">
  </div>

  <div class="mySlides">
    <div class="numbertext">2 / 6</div>
    <img src="hote04.jpg" style="width:100%">
  </div>

  <div class="mySlides">
    <div class="numbertext">3 / 6</div>
    <img src="hote6.jpg" style="width:100%">
  </div>
    
  <div class="mySlides">
    <div class="numbertext">4 / 6</div>
    <img src="hote06.jpg" style="width:100%">
  </div>

  <div class="mySlides">
    <div class="numbertext">5 / 6</div>
    <img src="hotel0.jpg" style="width:100%">
  </div>
    
  <div class="mySlides">
    <div class="numbertext">6 / 6</div>
    <img src="hotel01.jpg" style="width:100%">
  </div>
    
  <a class="prev" onclick="plusSlides(-1)">❮</a>
  <a class="next" onclick="plusSlides(1)">❯</a>

  <div class="caption-container">
    <p id="caption"></p>
  </div>

  <div class="row">
    <div class="column">
      <img class="demo cursor" src="hote00.jpg" style="width:100%" onclick="currentSlide(1)" alt="Fligts Deals Under $199">
    </div>
    <div class="column">
      <img class="demo cursor" src="hote04.jpg" style="width:100%" onclick="currentSlide(2)" alt="Free Flight Friday">
    </div>
    <div class="column">
      <img class="demo cursor" src="hote6.jpg" style="width:100%" onclick="currentSlide(3)" alt="">
    </div>
    <div class="column">
      <img class="demo cursor" src="hote06.jpg" style="width:100%" onclick="currentSlide(4)" alt="Northern Lights">
    </div>
    <div class="column">
      <img class="demo cursor" src="hotel0.jpg" style="width:100%" onclick="currentSlide(5)" alt="Nature and sunrise">
    </div>    
    <div class="column">
      <img class="demo cursor" src="hotel01.jpg" style="width:100%" onclick="currentSlide(6)" alt="">
    </div>
  </div>
</div>

<br><br><br><br><br><br><br><br><br><br>

<footer class="section footer-classic context-dark bg-image" style="background: #2d3246;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
              <div class="pr-xl-4"><a class="brand" href="index.html"><img class="brand-logo-light" src="images/agency/logo-inverse-140x37.png" alt="" width="140" height="37" srcset="images/agency/logo-retina-inverse-280x74.png 2x"></a>
                <p style="color: red;size: 30px ">Our goal is to change the way people stay away from home</p>
                <!-- Rights-->
                <p class="rights"><span>©  </span><span class="copyright-year">2018</span><span> </span><span>Waves</span><span>. </span><span>All Rights Reserved.</span></p>
              </div>
            </div>
            <div class="col-md-4">
              <h5>Contacts</h5>
              <dl class="contact-list">
                <dt>Address:</dt>
                <dd>798 South Park Avenue, Jaipur, Raj</dd>
              </dl>
              <dl class="contact-list">
                <dt>email:</dt>
                <dd><a href="shivam098t@gmail.com">shivam098t@gmail.com</a></dd>
              </dl>
              <dl class="contact-list">
                <dt>phones:</dt>
                <dd><a href="tel:#">+91 7568543012</a> <span>or</span> <a href="tel:#">+91 9571195353</a>
                </dd>
              </dl>
            </div>
            <div class="col-md-4 col-xl-3">
              <h5>Links</h5>
              <ul class="nav-list">
                <li><a href="index.php">About</a></li>
                <li><a href="gallery.php">Visit Our Gallery</a></li>
                <li><a href="offer.php">Hot Deals</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="contact.php">Register</a></li>
              </ul>
            </div>
          </div>
        </div>
   
      </footer>
</body>
</html>