<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>




  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



   <script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>






	<style>



  	.header{
        text-align: center;
        color: red;
		}
    * {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial Helvetica sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: black;
}

.topnav a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #00BFFF;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
 






* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial;
}

.header {
    text-align: center;
    padding: 32px;
}

.row {
    display: -ms-flexbox; /* IE10 */
    display: flex;
    -ms-flex-wrap: wrap; /* IE10 */
    flex-wrap: wrap;
    padding: 0 4px;
}

/* Create four equal columns that sits next to each other */
.column {
    -ms-flex: 25%; /* IE10 */
    flex: 25%;
    max-width: 25%;
    padding: 0 4px;
}

.column img {
    margin-top: 8px;
    vertical-align: middle;
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 800px) {
    .column {
        -ms-flex: 50%;
        flex: 50%;
        max-width: 50%;
    }
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .column {
        -ms-flex: 100%;
        flex: 100%;
        max-width: 100%;
    }
}





 .context-dark, .bg-gray-dark, .bg-primary {
    color: rgba(255, 255, 255, 0.8);
}

.footer-classic a, .footer-classic a:focus, .footer-classic a:active {
    color: #ffffff;
}
.nav-list li {
    padding-top: 5px;
    padding-bottom: 5px;
}

.nav-list li a:hover:before {
    margin-left: 0;
    opacity: 1;
    visibility: visible;
}

ul, ol {
    list-style: none;
    padding: 0;
    margin: 0;
}


.nav-list li a:before {
    content: "\f14f";
    font: 400 21px/1 "Material Design Icons";
    color: #4d6de6;
    display: inline-block;
    vertical-align: baseline;
    margin-left: -28px;
    margin-right: 7px;
    opacity: 0;
    visibility: hidden;
    transition: .22s ease;
}




</style>
	<title></title>
</head>
<body>
<!-- Header -->



 <div class="header" >
  <h1><label>Welcome to Dream Rooms</label></h1>
  <p style="color: red;size: 40px"><i>A House Is Made Up Of Bricks And Beams.
  Dream Homes Are Made Up Of Hopes And Dreams</i></p><hr style="margin-left: 400px; margin-right: 400px"><br><br><br><br>
 </div>
 <div class="topnav">
  <div class="sticky">
  <a class="active" href="index.php">Home</a>
  <a href="gallery.php">Gallery</a>
  <a href="offer.php">Latest Offer</a>
  <a href="events.php">Events</a>
  <a href="chart.php">Statics</a>
  <?php if (!empty($_SESSION["NAME"])) { ?>
  <a href="#">Hii, <?php echo $_SESSION["NAME"];?></a>
  <a href="logout.php">logout</a>
  <?php }
  else { ?>
  <a href="loginuser.php">Login</a>
  <a href="contact.php">Register</a>
  <?php } ?>
  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
  </div>
</div><br><br><br><br><br><br>
 


<div class="header">
  <h1>Gallery</h1><hr style="margin-left: 400px; margin-right: 400px">
  <p>Dream Rooms Is Where Your Story Begins</p>
</div>

<!-- Photo Grid -->
<div class="row"> 
  <div class="column">
    <img src="hotel1.jpg" style="width:100%">
    <img src="hotel6.jpg" style="width:100%">
    <img src="hote13.jpg" style="width:100%">
    <img src="hote10.jpg" style="width:100%">
    <img src="hote11.jpg" style="width:100%">
    <img src="hote14.jpg" style="width:100%">
    <img src="hote44.jpg" style="width:100%">
  </div>
  <div class="column">
    <img src="hotel45.jpg" style="width:100%">
    <img src="hotel40.jpg" style="width:100%">
    <img src="hotel2.jpg" style="width:100%">
    <img src="hotel3.jpg" style="width:100%">
    <img src="hotel4.jpg" style="width:100%">
    <img src="hotel8.jpg" style="width:100%">
  </div>  
  <div class="column">
    <img src="hotel21.jpg" style="width:100%">
    <img src="hote46.jpg" style="width:100%">
    <img src="hotel23.jpg" style="width:100%">
    <img src="hotel25.jpg" style="width:100%">
    <img src="hotel26.jpg" style="width:100%">
    <img src="hote25.jpg" style="width:100%">
    <img src="hote20.jpg" style="width:100%">
  </div>
  <div class="column">
    <img src="hotel42.jpg" style="width:100%">
    <img src="hotel32.jpg" style="width:100%">
    <img src="hotel35.jpg" style="width:100%">
   
  </div>
</div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>





<footer class="section footer-classic context-dark bg-image" style="background: #2d3246;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
              <div class="pr-xl-4"><a class="brand" href="index.html"><img class="brand-logo-light" src="images/agency/logo-inverse-140x37.png" alt="" width="140" height="37" srcset="images/agency/logo-retina-inverse-280x74.png 2x"></a>
                <p>We are an award-winning creative agency, dedicated to the best result in web design, promotion, business consulting, and marketing.</p>
                <!-- Rights-->
                <p class="rights"><span>©  </span><span class="copyright-year">2018</span><span> </span><span>Waves</span><span>. </span><span>All Rights Reserved.</span></p>
              </div>
            </div>
            <div class="col-md-4">
              <h5>Contacts</h5>
              <dl class="contact-list">
                <dt>Address:</dt>
                <dd>798 South Park Avenue, Jaipur, Raj</dd>
              </dl>
              <dl class="contact-list">
                <dt>email:</dt>
                <dd><a href="mailto:#">dkstudioin@gmail.com</a></dd>
              </dl>
              <dl class="contact-list">
                <dt>phones:</dt>
                <dd><a href="tel:#">+91 7568543012</a> <span>or</span> <a href="tel:#">+91 9571195353</a>
                </dd>
              </dl>
            </div>
            <div class="col-md-4 col-xl-3">
              <h5>Links</h5>
              <ul class="nav-list">
                <li><a href="index.php">About</a></li>
                <li><a href="events.php">Projects</a></li>
                <li><a href="offers.php">Some Hot Deals</a></li>
                <li><a href="contact.php">Contacts</a></li>
                <li><a href="gallery.php">Patners</a></li>
              </ul>
            </div>
          </div>
        </div>
   
      </footer>

</body>
</html>