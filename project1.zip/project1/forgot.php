<?php
if (isset($_POST['submit'])) {
$a=$_POST['inputemail3'];
$servername="localhost";
$username="root";
$password="";
$dbname="ehotels";
$conn=mysqli_connect($servername,$username,$password,$dbname);

$sql="select * from registration where email='$a'";
$result=mysqli_query($conn,$sql);
  if (mysqli_num_rows($result)) {
    $row=mysqli_fetch_assoc($result);
    $mobile=$row["mobileno"];
$message="hi this is your password".$row["password"];
$json = json_decode(file_get_contents("https://smsapi.engineeringtgr.com/send/?Mobile=8502071173&Password=pstmerabhai&Message=".urlencode($message)."&To=".urlencode($mobile)."&Key=ravibm4FoD7dWGu6bvpCK5J") ,true);
if ($json["status"]==="success") {
    echo $json["msg"];
    //your code when send success
}else{
    echo $json["msg"];
    //your code when not send
}
  }
  else
    echo "no";
}
  ?>
<div class="row well">
  <div class="col-md-4"></div>
  <div class="col-md-4 well">
    <center><b>FORGET PASSWORD</b></center><br><br>
    <div class="col-md-2"></div>
    <div class="col-md-5 well" style="width: 100%;height: 250px;background-color: white">
      <center>
      <form action="forgot.php" method="POST">
        Enter email&nbsp:<input type="Email" name="inputemail3" placeholder="enter email " class="form-control" style="text-align: center">
        <input type="submit" name="submit" class="form-control">
      </form>
      </center>
    </div>
  </div>
</div>
</div>
</body>
</html>
