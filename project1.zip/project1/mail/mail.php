<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
    //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = '2017pietcsshivam098@poornima.org';                 // SMTP username
    $mail->Password = 'shivi098';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('2017pietcsshivam098@poornima.org', 'Mailer');
    $mail->addAddress('goyalnimish2864@gmail.com', 'Joe User');     // Add a recipient
    //$mail->addAddress('ellen@example.com');               // Name is optional
    //$mail->addReplyTo('info@example.com', 'Information');
   // $mail->addCC('cc@example.com');
   // $mail->addBCC('bcc@example.com');

    //Attachments
   // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
  //  $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Hai thank you for registering';
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    //echo 'Message has been sent';
    {
        $servername="localhost";
$username="root";
$password="";
$dbname="ehotels";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$first_name=$_POST['s0'];
$last_name=$_POST['s1'];
$mobileno=$_POST['s2'];
$email=$_POST['s3'];
$password=$_POST['s4'];
$gender=$_POST['s5'];

$sql="INSERT INTO `registration`(`first_name`, `last_name`, `mobileno`, `email`, `password`, `gender`) VALUES ('$first_name','$last_name','$mobileno','$email','$password','$gender')";
if (mysqli_query($conn,$sql))
 {
    header("location:../loginuser.php");   
}
else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
    }
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
