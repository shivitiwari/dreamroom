<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>




  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>



<script type="text/javascript">
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}


   function ok(){ 
    var fname = document.getElementById('1').value;
    

      if(fname ==""){
      document.getElementById('1').innerHTML="** Please fill the fname" ;
      return false;
      alert"Please fill the fname";
    }
    if((fname.length <=2) || (fname.length> 30)){
      document.getElementById('1').innerHTML="** user length mustbe 3 to 29" ;
      return false;
      alert"user length mustbe 3 to 29";
    }
    if(!isNaN(fname)){
      document.getElementById('1').innerHTML="** only characters are allowed " ;
      return false;
      alert"only characters are allowed ";

}

var lname = document.getElementById('2').value;
      
      if(lname ==""){
      document.getElementById('2').innerHTML="** Please fill the lname" ;
      return false;
      alert" Please fill the lname";
    }
    if((lname.length <=2) || (lname.length> 30)){
      document.getElementById('2').innerHTML="** user length mustbe 3 to 29" ;
      return false;
      alert"user length mustbe 3 to 29";
    }
    if(!isNaN(lname)){
      document.getElementById('2').innerHTML="** only characters are allowed " ;
      return false;
      alert"only characters are allowed";

}



        var email = document.getElementById('4').value;
    
    if(email ==""){
      document.getElementById('4').innerHTML="** Please fill the email id" ;
      return false;
      alert"Please fill the email id";
        
    
    }
            var number= document.getElementById('3').value;
      
      if( number==""){
      document.getElementById('3').innerHTML=" ** Please fill the Mobile number" ;
      return false;
      alert"Please fill the Mobile number";
    }
           if(isNaN(number)){
      document.getElementById('3').innerHTML="** mobile number must be digit" ;
      return false;
      alert"mobile number must be digit";
    }
if(number.length!=10){
  
    
      document.getElementById('3').innerHTML="** number not less than 10 digit" ;
      return false;
      alert" number not less than 10 digit";
}
    var password= document.getElementById('5').value;
      if(password ==""){
      document.getElementById('5').innerHTML= " **Please fill the password" ;
      return false;
       alert"Please fill the password";
    }
      if((password.length <=6) || (password.length> 30)){
      document.getElementById('5').innerHTML="** password length mustbe 6 to 29" ;
      return false;
      alert"password length mustbe 6 to 29";    
        

         
    
         
     }
  var conformpassword= document.getElementById('6').value;
        if(conformpassword ==""){
    document.getElementById('6').innerHTML = " **Please fill the conform password field" ;
    return false;
    alert"Please fill the conform password field";
  }


        if(password!=conformpassword){
      document.getElementById('6').innerHTML="** passwords are not matching" ;
      return false;
      alert" passwords are not matching";


}
var date=document.getElementById('date').value;
           if(date==""){
            document.getElementById('Date').innerHTML=" ** date should be filled";
            return false;
            alert"date should be filled";
           }

 
var a= 0, rdbtn=document.getElementsByName("s5")
for(i=0;i<rdbtn.length;i++) {
if(rdbtn.item(i).checked == false) {
a++;
}
}

if(a == rdbtn.length) {
document.getElementById("7").innerHTML= "** gender have to fill";
return false;
alert"gender have to fill";
} 
window.location.assign("loginuser.php");
}
}
</script>

    <style type="text/css">
    body{background-image: url(hote10.jpg);
        background-size:cover;
        background-position: top;
        background-blend-mode: multiply;
    }
    .form{

        background-color:black;
        opacity: 0.8;
        width: 650px;
        height: 800px;
        margin-left:400px;
        margin-top: 50px;
    }





    .context-dark, .bg-gray-dark, .bg-primary {
    color: rgba(255, 255, 255, 0.8);
}

.footer-classic a, .footer-classic a:focus, .footer-classic a:active {
    color: #ffffff;
}
.nav-list li {
    padding-top: 5px;
    padding-bottom: 5px;
}

.nav-list li a:hover:before {
    margin-left: 0;
    opacity: 1;
    visibility: visible;
}

ul, ol {
    list-style: none;
    padding: 0;
    margin: 0;
}


.nav-list li a:before {
    content: "\f14f";
    font: 400 21px/1 "Material Design Icons";
    color: #4d6de6;
    display: inline-block;
    vertical-align: baseline;
    margin-left: -28px;
    margin-right: 7px;
    opacity: 0;
    visibility: hidden;
    transition: .22s ease;
}


hr {border-top: 1px solid #000; width:50%;}

a {color: #000;}

a:link{text-decoration:none;}

#contact2{
    letter-spacing:3px;
}



#author a{
  color: #fff;
  text-decoration: none;
    
}






</style>


<!--	<script type="text/javascript">
       
	function ok()
	 {
        
		var a=document.getElementById("1").value;
		var b=document.getElementById("2").value;
		var c=document.getElementById("3").value;
		var d=document.getElementById("4").value;
        var e=document.getElementById("5").value;
        var f=document.getElementsByName('s');
        

         if (a=="" || b=="" || c==""|| d=="" || e=="" || f[0].checked==false && f[1]==false) 
         {
         	alert('fill up all the fields');
         	return false();
         	
         }
         else{
              alert('Your Record Has Sucessfully Inserted');
         }
	}
</script>  -->

<script type="text/javascript">
 
  
</script>






	<title>Get In Touch</title>
</head>
<body>
	
    <h1 align="center">GET IN TOUCH</h1>
	<div class="form">
	<table BORDER="none" border="transparent" height="720px" width="650px" align="center" cellpadding="12px" cellspacing="12px" style="margin-top: -100px;"  > 
	   <form method="POST" action="registration.php"  style="background-color: blue" onsubmit="return ok()" >
    		<tr><td align="center" ><h2 style="font-weight: bolder;color: blue">REGISTERATION FORM  </h2></td></tr>
            
            <tr><td><label style="color:skyblue ">First Name :</label><input type="name" name="s0" id="1" required=""></td></tr><br>
            <tr><td><b style="color: skyblue">Last Name:<input type="text" name="s1" id="2" required=""  ></b></td></tr><br>
            <tr><td><b style="color: skyblue">Mobile Number:<input type="text" name="s2" id="3" placeholder="Enter Mobile Number" required="" ></b></td></tr><br>
            <tr><td><b style="color: skyblue">E-mail Id :<input type="email" name="s3" id="4" placeholder="Enter your E-mail " required=""></b></td></tr><br>
            <tr><td><b style="color: skyblue">Password :<input type="password" name="s4" id="5" placeholder="at least 8 digits" maxlength="20" minlength="8" required="" ></b></td></tr><br>
             <tr><td><b style="color: skyblue"> Re-Password :<input type="password" name="s4" id="6" placeholder="at least 8 digits" required="" ></b></td></tr><br>
        
            <tr><td><b style="color: skyblue"> Choose your Gender:<input type="radio" name="s5" id="7" required="" >:Mr</b>
             <b style="color: skyblue"><input type="radio" name="s5" id="8" required="" >:Mrs
              <input type="radio" name="s5" id="i2" required="" >:Other</b></td></tr><br>
            <tr><td><b><input type="Reset"  name="2" id="8"  class="form-control btn btn-danger"></b><br><br>
            <button style="color: white" class="form-control btn btn-success"><label><center> Register</label></center></button>
             </td></tr>
             <input type="" class="form-control btn btn-danger" style="margin-top: -115px">

        </form>
    </table>
</div>








 <br><br><br><br><br><br><br><br>



<div class="row well" >

    <div class="col-sm-4" id="contact2" style="margin-left: 650px;">
        <h3>About Us</h3>
        <hr align="left" width="50%">
        <h4 class="pt-2">Resedential Address</h4>
        <i class="fas fa-globe" style="color:#000"></i> 798 South Park Avenue, Jaipur, Raj<br>
        <h4 class="pt-2">Contact Number</h4>
        <i class="fas fa-phone" style="color:#000"></i> <a href="tel:+"> 9829056646 </a><br>
        <i class="fab fa-whatsapp" style="color:#000"></i><a href="tel:+"> 9782488003 </a><br>
        <h4 class="pt-2">Email-Id</h4>
        <i class="fa fa-envelope" style="color:#000"></i> <a href="">shivam098t@gmail.com</a><br>
      </div>
  </div>







<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3562.242623142438!2d75.84849331504189!3d26.76853498318986!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396dc91e898380fd%3A0xeee859ae1f1b64b0!2sPoornima+Institute+of+Engineering+and+Technology!5e0!3m2!1sen!2sin!4v1540889566530" width="1500" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

 <br><br><br><br><br><br><br><br>
 <br><br><br><br><br><br><br><br>

<footer class="section footer-classic context-dark bg-image" style="background: #2d3246;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
              <div class="pr-xl-4"><a class="brand" href="index.html"><img class="brand-logo-light" src="images/agency/logo-inverse-140x37.png" alt="" width="140" height="37" srcset="images/agency/logo-retina-inverse-280x74.png 2x"></a>
                <p style="color: red;size: 30px ">Our goal is to change the way people stay away from home</p>
                <!-- Rights-->
                <p class="rights"><span>©  </span><span class="copyright-year">2018</span><span> </span><span>Waves</span><span>. </span><span>All Rights Reserved.</span></p>
              </div>
            </div>
            <div class="col-md-4">
              <h5>Contacts</h5>
              <dl class="contact-list">
                <dt>Address:</dt>
                <dd>798 South Park Avenue, Jaipur, Raj</dd>
              </dl>
              <dl class="contact-list">
                <dt>email:</dt>
                <dd><a href="shivam098t@gmail.com">shivam098t@gmail.com</a></dd>
              </dl>
              <dl class="contact-list">
                <dt>phones:</dt>
                <dd><a href="tel:#">+91 7568543012</a> <span>or</span> <a href="tel:#">+91 9571195353</a>
                </dd>
              </dl>
            </div>
            <div class="col-md-4 col-xl-3">
              <h5>Links</h5>
              <ul class="nav-list">
                <li><a href="index.php">About</a></li>
                <li><a href="gallery.php">Visit Our Gallery</a></li>
                <li><a href="offer.php">Hot Deals</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="contact.php">Register</a></li>
              </ul>
            </div>
          </div>
        </div>
   
      </footer>



</body>
</html>