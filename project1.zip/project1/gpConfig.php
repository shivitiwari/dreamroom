<?php
session_start();

//Include Google client library 
include_once 'googlelogin/src/Google_Client.php';
include_once 'googlelogin/src/contrib/Google_Oauth2Service.php';

/*
 * Configuration and setup Google API
 */
$clientId = '391693404913-i3dokfrp4iapcqbghmcgm7p6uceodbva.apps.googleusercontent.com'; //Google client ID
$clientSecret = 'eJMWmFHbaaHMjpCTSULbaRO7'; //Google client secret
$redirectURL = 'https://2017pietcsshivam098.000webhostapp.com/'; //Callback URL

//Call Google API
$gClient = new Google_Client();
$gClient->setApplicationName('Login to CodexWorld.com');
$gClient->setClientId($clientId);
$gClient->setClientSecret($clientSecret);
$gClient->setRedirectUri($redirectURL);

$google_oauthV2 = new Google_Oauth2Service($gClient);
?>